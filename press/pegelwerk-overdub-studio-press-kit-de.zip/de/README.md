# pegelWERK overdub STUDIO, Press Kit (Deutsch)

Stand: Juni 2026

Dieses Verzeichnis enthält alle Materialien für die redaktionelle Berichterstattung über pegelWERK overdub STUDIO 1.1.1. Texte dürfen frei verwendet werden; Bildmaterial ist für redaktionelle Nutzung unter Nennung von pegelWERK lizenziert.

## Inhalt

| Datei | Zweck |
|---|---|
| README.md (diese Datei) | Überblick |
| press-release.pdf / .txt | Pressemitteilung (A4-PDF + Klartext) |
| fact-sheet.pdf / .md | Specs, Preise, Plattformen |
| boilerplate.txt | Kurze Standardbeschreibungen zum Einbetten in Artikel |
| assets/pegelwerk-logo.png | pegelWERK-Logo (quadratisch) |
| assets/overdub-studio-icon.png | overdub STUDIO App-Icon (1024x1024) |
| assets/overdub-studio-hero.png | Hero-Screenshot der App-UI |
| assets/pegelwerk-og-image.png | Open-Graph-Bild (1200x630) |

## Hinweise zur Bildnutzung

- Alle Bilder liegen hochauflösend als PNG vor.
- Freie Nutzung in Online- und Print-Berichterstattung über pegelWERK, ohne gesonderte Genehmigung, sofern pegelWERK als Quelle genannt wird.
- Ausschnitte und redaktionelle Anpassungen sind erlaubt. Bitte das Logo nicht verzerren oder umfärben.

## Pressekontakt

Sascha Hömske, pegelWERK, info@pegelwerk.com, pegelwerk.com
Trailer: pegelwerk.com/videos
