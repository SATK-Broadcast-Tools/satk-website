# pegelWERK overdub STUDIO — Press Kit (Deutsch)

Stand: 30. Mai 2026

Dieses Verzeichnis enthält alle Materialien für die redaktionelle
Berichterstattung über pegelWERK overdub STUDIO. Texte dürfen frei
verwendet werden; Bildmaterial ist für redaktionelle Nutzung unter
Nennung von „pegelWERK" lizenziert.

## Inhalt

| Datei | Zweck |
|---|---|
| `README.md` *(diese Datei)* | Überblick + vollständige Pressemitteilung |
| `press-release.pdf` / `.txt` | Pressemitteilung (A4-PDF + Klartext) |
| `fact-sheet.pdf` / `.md` / `.txt` | Specs, Preise, Plattformen |
| `boilerplate.txt` | Kurze Standardbeschreibungen zum Einbetten in Artikel |
| `press-flyer.pdf` | Gestalteter Pressemitteilungs-Flyer (A4) |
| `assets/pegelwerk-logo.png` | pegelWERK-Logo (quadratisch, 1183×1083) |
| `assets/overdub-studio-icon.png` | overdub STUDIO App-Icon (1024×1024) |
| `assets/overdub-studio-hero.png` | Hero-Screenshot der App-UI |
| `assets/pegelwerk-og-image.png` | Open-Graph-Bild (1200×630) |
| `assets/press-flyer-de.png` | Pressemitteilungs-Flyer (A4, Deutsch) |
| `assets/sales-flyer-de.png` | Feature-Flyer für Newsletter / Print (A4, Deutsch) |

## Hinweise zur Bildnutzung

- Alle Bilder liegen hochauflösend als PNG vor
- Freie Nutzung in Online- und Print-Berichterstattung über pegelWERK,
  ohne gesonderte Genehmigung, sofern „pegelWERK" als Quelle genannt wird
- Ausschnitte und redaktionelle Anpassungen sind erlaubt
- Bitte das Logo nicht verzerren oder umfärben

## Pressekontakt

Sascha Hömske, pegelWERK · info@pegelwerk.com · pegelwerk.com
