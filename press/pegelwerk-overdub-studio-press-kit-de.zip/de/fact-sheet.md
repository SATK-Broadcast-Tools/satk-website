# Faktenblatt — pegelWERK overdub STUDIO

Stand: 30. Mai 2026

## Produkt
- Produkt-Name: pegelWERK overdub STUDIO
- Version: 1.0.6
- Kategorie: Vertonungs-DAW (Voiceover-to-Video)
- Release-Datum: 14. Mai 2026 (1.0), 1.0.6 als aktuelles Release
- Hersteller: pegelWERK
- Sitz: Siegburg, Deutschland
- Gründer / Inhaber: Sascha Hömske

## Plattformen
- macOS: Direkt über pegelwerk.com (Paddle) — Standalone
- iPad: Apple App Store — iOS-App, optimiertes Layout

## Systemanforderungen (macOS)
- Empfohlen: Apple Silicon (M-Serie), 16 GB RAM, macOS 13 oder neuer
- Unterstützt: Intel Quad-Core i7, 16 GB RAM, macOS 12

## Preise
- macOS Standalone: 199 € — Einmalkauf
- iPad (App Store): monatliches Abo

## Kernfunktionen
- Auto Edit: Pausen automatisch entfernt während der Aufnahme
- Auto Audio: Stimme automatisch klar, gleichmäßig, auf Sendelautstärke (EBU R128 −23 LUFS)
- Auto Mix: Sprache, Musik, Effekte in einem Klick in Balance
- Prompter: Text läuft mit der Stimme mit (macOS, On-Device-Erkennung)
- Video-Export: Fertige Vertonung direkt ins Quellvideo eingebettet, MXF-treu

## pegelWERK Tool-Familie
- broadcast METER: Loudness-Meter (macOS, iPad)
- mini METER: Loudness-Meter für iPhone
- loudness CORRECT: Offline-Lautheitskorrektur (macOS, iPad)
- easy EDITOR: Audio-Cutter mit R128-Export (iPhone, iPad)
- instant PLAYER: 64-Pad-Soundboard (iPhone, iPad)

## Distribution & Lizenz
- macOS: Hardware-gebundene Lizenz, 2 Geräte pro Lizenz, kein iLok, kein USB-Dongle
- iPad: Apple App Store DRM (FairPlay)
- Trial: Kostenlose Testversion verfügbar

## URLs
- Produkt-Seite: pegelwerk.com/overdub-studio-pro
- Download macOS DMG: pegelwerk.com/download/pegelwerk-overdub-studio-1.0.6.dmg
- Hersteller: pegelwerk.com
- Pressekontakt: info@pegelwerk.com
