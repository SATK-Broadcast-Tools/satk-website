# Faktenblatt, pegelWERK overdub STUDIO

Stand: Juni 2026

## Produkt
- Name: pegelWERK overdub STUDIO
- Version: 1.1.1
- Kategorie: Vertonungs-DAW (Voiceover-to-Video), seit 1.1.1 auch Audio-only
- Hersteller: pegelWERK, Siegburg, Deutschland
- Gründer: Sascha Hömske

## Plattformen
- macOS: Standalone, über pegelwerk.com (Paddle)
- iPad: Apple App Store

## Systemanforderungen (macOS)
- Empfohlen: Apple Silicon, 16 GB RAM, macOS 13 oder neuer
- Unterstützt: Intel i7, 16 GB RAM, macOS 12

## Preise overdub STUDIO (Abo)
- macOS: 24,99 EUR / Monat oder 249 EUR / Jahr
- iPad: 12,99 EUR / Monat oder 129 EUR / Jahr
- Kostenlose Testversion auf macOS

## Kernfunktionen
- Auto Edit: Pausen automatisch entfernt während der Aufnahme
- Auto DSP: Stimme automatisch klar, gleichmäßig, auf Sendelautstärke (EBU R128)
- Auto Mix: Sprache, Musik und Originalton in einem Klick in Balance
- Prompter: läuft mit der Stimme mit, auf macOS und iPad, Erkennung auf dem Gerät
- Video-Export: fertige Vertonung direkt ins Quellvideo eingebettet, MXF-treu (macOS)

## Neu in 1.1.1
- Audio-only-Modus für Podcasts und Hörbücher, ohne Video
- Neuronale Entrauschung (DeepFilterNet 3), on-device, kein Plug-in, kein Upload
- Manueller Konsolen-Strip: Monitor, Noise, Comp, Air, Body

## pegelWERK Lineup und Preise
| Produkt | Plattform | Preis | Modell |
|---|---|---|---|
| overdub STUDIO | macOS | 24,99 EUR/Mo oder 249 EUR/Jahr | Abo |
| overdub STUDIO | iPad | 12,99 EUR/Mo oder 129 EUR/Jahr | Abo |
| broadcast METER | macOS (PRO) | 129 EUR | Einmalkauf |
| broadcast METER | iPad | 19,99 EUR | Einmalkauf |
| mini METER | iPhone | 9,99 EUR | Einmalkauf |
| loudness CORRECT | macOS | 199 EUR | Einmalkauf |
| loudness CORRECT | iPad | 19,99 EUR | Einmalkauf |
| easy EDITOR | iPhone/iPad | 4,99 EUR | Einmalkauf |
| instant PLAYER | iPhone/iPad | kostenlos | Gratis |

Alle Apps teilen dieselbe EBU-R128-DSP-Engine. overdub STUDIO ist die einzige Abo-App, alle anderen sind Einmalkauf.

## Distribution und Lizenz
- macOS: hardware-gebundene Lizenz, 2 Geräte pro Lizenz, kein iLok, kein USB-Dongle
- iPad: Apple App Store DRM (FairPlay)

## URLs
- Produktseite: pegelwerk.com/overdub-studio-pro
- Trailer: pegelwerk.com/videos
- Hersteller: pegelwerk.com
- Pressekontakt: Sascha Hömske, info@pegelwerk.com
