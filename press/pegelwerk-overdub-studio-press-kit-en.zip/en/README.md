# pegelWERK overdub STUDIO — Press Kit (English)

As of: 30 May 2026

This directory contains all materials editorial teams need to cover
pegelWERK overdub STUDIO. Texts may be reused freely; image assets are
licensed for editorial use with credit to "pegelWERK".

## Contents

| File | Purpose |
|---|---|
| `README.md` *(this file)* | Overview + full press release |
| `press-release.pdf` / `.txt` | Press release (A4 PDF + plain text) |
| `fact-sheet.pdf` / `.md` / `.txt` | Specs, pricing, platforms |
| `boilerplate.txt` | Short standard descriptions for embedding in articles |
| `press-flyer.pdf` | Designed press release flyer (A4) |
| `assets/pegelwerk-logo.png` | pegelWERK logo (square, 1183×1083) |
| `assets/overdub-studio-icon.png` | overdub STUDIO app icon (1024×1024) |
| `assets/overdub-studio-hero.png` | Hero screenshot of the app UI |
| `assets/pegelwerk-og-image.png` | Open Graph image (1200×630) |
| `assets/press-flyer-en.png` | Press release flyer (A4, English) |
| `assets/sales-flyer-en.png` | Feature flyer for newsletters / print (A4, English) |

## Image usage notes

- All images are provided at high resolution as PNGs
- Free use in online and print coverage about pegelWERK, no separate
  permission required, provided "pegelWERK" is credited as the source
- Crops and editorial adjustments are allowed
- Please do not stretch the logo or recolour it

## Press Contact

Sascha Hömske, pegelWERK · info@pegelwerk.com · pegelwerk.com
