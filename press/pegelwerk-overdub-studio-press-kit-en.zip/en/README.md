# pegelWERK overdub STUDIO, Press Kit (English)

As of: June 2026

This folder contains all materials for editorial coverage of pegelWERK overdub STUDIO 1.1.1. Texts may be used freely; image material is licensed for editorial use with credit to pegelWERK.

## Contents

| File | Purpose |
|---|---|
| README.md (this file) | Overview |
| press-release.pdf / .txt | Press release (A4 PDF + plain text) |
| fact-sheet.pdf / .md | Specs, pricing, platforms |
| boilerplate.txt | Short standard descriptions for embedding in articles |
| assets/pegelwerk-logo.png | pegelWERK logo (square) |
| assets/overdub-studio-icon.png | overdub STUDIO app icon (1024x1024) |
| assets/overdub-studio-hero.png | Hero screenshot of the app UI |
| assets/pegelwerk-og-image.png | Open Graph image (1200x630) |

## Image usage

- All images are provided as high-resolution PNG.
- Free use in online and print coverage of pegelWERK, without separate permission, as long as pegelWERK is credited as the source.
- Crops and editorial adjustments are allowed. Please do not distort or recolour the logo.

## Press contact

Sascha Hömske, pegelWERK, info@pegelwerk.com, pegelwerk.com
Trailer: pegelwerk.com/videos
