# Fact Sheet — pegelWERK overdub STUDIO

As of: 30 May 2026

## Product
- Product name: pegelWERK overdub STUDIO
- Version: 1.0.6
- Category: Voiceover-to-video DAW
- Release date: 14 May 2026 (1.0), 1.0.6 current release
- Vendor: pegelWERK
- Headquarters: Siegburg, Germany
- Founder / Owner: Sascha Hömske

## Platforms
- macOS: Direct from pegelwerk.com (Paddle) — Standalone
- iPad: Apple App Store — iOS app, optimised layout

## System Requirements (macOS)
- Recommended: Apple Silicon (M-series), 16 GB RAM, macOS 13 or later
- Supported: Intel Quad-Core i7, 16 GB RAM, macOS 12

## Pricing
- macOS Standalone: 199 € — one-time purchase
- iPad (App Store): monthly subscription

## Core Features
- Auto Edit: Pauses automatically removed during recording
- Auto Audio: Voice automatically processed to broadcast loudness (EBU R128 −23 LUFS)
- Auto Mix: Voice, music, effects balanced in one click
- Prompter: Script scrolls with the voice (macOS, on-device speech)
- Video Export: Finished mix embedded straight into the source video, MXF-safe

## pegelWERK Tool Family
- broadcast METER: Loudness meter (macOS, iPad)
- mini METER: Loudness meter for iPhone
- loudness CORRECT: Offline loudness correction (macOS, iPad)
- easy EDITOR: Audio cutter with R128 export (iPhone, iPad)
- instant PLAYER: 64-pad soundboard (iPhone, iPad)

## Distribution & Licensing
- macOS: Hardware-bound license, 2 devices per license, no iLok, no USB dongle
- iPad: Apple App Store DRM (FairPlay)
- Trial: Free trial available

## URLs
- Product page: pegelwerk.com/overdub-studio-pro
- macOS DMG download: pegelwerk.com/download/pegelwerk-overdub-studio-1.0.6.dmg
- Vendor: pegelwerk.com
- Press contact: info@pegelwerk.com
