# Fact Sheet, pegelWERK overdub STUDIO

As of: June 2026

## Product
- Name: pegelWERK overdub STUDIO
- Version: 1.1.1
- Category: voiceover DAW (voiceover-to-video), audio-only since 1.1.1
- Vendor: pegelWERK, Siegburg, Germany
- Founder: Sascha Hömske

## Platforms
- macOS: Standalone, via pegelwerk.com (Paddle)
- iPad: Apple App Store

## System requirements (macOS)
- Recommended: Apple Silicon, 16 GB RAM, macOS 13 or newer
- Supported: Intel i7, 16 GB RAM, macOS 12

## Pricing overdub STUDIO (subscription)
- macOS: EUR 24.99 / month or EUR 249 / year
- iPad: EUR 12.99 / month or EUR 129 / year
- Free trial on macOS

## Core features
- Auto Edit: pauses removed automatically while recording
- Auto DSP: voice automatically clear, even, at broadcast loudness (EBU R128)
- Auto Mix: voice, music and original sound balanced in one click
- Prompter: follows the voice, on macOS and iPad, on-device recognition
- Video export: finished mix embedded directly into the source video, MXF-safe (macOS)

## New in 1.1.1
- Audio-only mode for podcasts and audiobooks, no video
- Neural noise removal (DeepFilterNet 3), on-device, no plug-in, no upload
- Manual channel strip: Monitor, Noise, Comp, Air, Body

## pegelWERK lineup and pricing
| Product | Platform | Price | Model |
|---|---|---|---|
| overdub STUDIO | macOS | EUR 24.99/mo or 249/yr | Subscription |
| overdub STUDIO | iPad | EUR 12.99/mo or 129/yr | Subscription |
| broadcast METER | macOS (PRO) | EUR 129 | One-time |
| broadcast METER | iPad | EUR 19.99 | One-time |
| mini METER | iPhone | EUR 9.99 | One-time |
| loudness CORRECT | macOS | EUR 199 | One-time |
| loudness CORRECT | iPad | EUR 19.99 | One-time |
| easy EDITOR | iPhone/iPad | EUR 4.99 | One-time |
| instant PLAYER | iPhone/iPad | free | Free |

All apps share the same EBU R128 DSP engine. overdub STUDIO is the only subscription app, all others are one-time purchases.

## Distribution and licence
- macOS: hardware-bound licence, 2 devices per licence, no iLok, no USB dongle
- iPad: Apple App Store DRM (FairPlay)

## URLs
- Product page: pegelwerk.com/overdub-studio-pro
- Trailer: pegelwerk.com/videos
- Vendor: pegelwerk.com
- Press contact: Sascha Hömske, info@pegelwerk.com
