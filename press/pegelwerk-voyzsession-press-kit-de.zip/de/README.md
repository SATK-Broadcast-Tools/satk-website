# pegelWERK voyzSESSION — Press Kit (DE)

Inhalt:
- press-release.pdf / .txt — Pressemitteilung zu Version 1.6.0
- fact-sheet.pdf / .md — Fact Sheet
- boilerplate.txt — Kurzprofil pegelWERK
- assets/voyzsession-icon.png — App-Icon (1024x1024)
- assets/voyzsession-hero.png — Screenshot
- assets/pegelwerk-logo.png — Hersteller-Logo

Alle Materialien sind zur redaktionellen Verwendung freigegeben.
Pressekontakt: Sascha Hömske · info@pegelwerk.com · pegelwerk.com
