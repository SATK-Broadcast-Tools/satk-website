# voyzSESSION - Fact Sheet

**Die DAW für Sprachproduktion: Voice-over, Beitrag, Podcast, Hörspiel.**

- **Produkt:** voyzSESSION - DAW für Sprachproduktion mit R128-Automatik und Handmodus
- **Kategorie:** Voice-over- und Podcast-Produktion, Audio-Postproduktion, Broadcast-Auslieferung
- **Plattformen:** macOS 12+ (Apple Silicon und Intel, Universal Binary) - iPadOS
- **Arbeitsweisen:** Assist-Modus mit Auto Edit, Auto DSP und Auto Mix - Manual-Modus mit Kanalzügen, Gruppen und Automation in Read, Touch, Latch und Write
- **Aufnahme:** Direkt in den Projektordner, 32 Bit Fließkomma - Overdub gegen Video oder Skript - V-PUNCH, der sprachgesteuerte Ein- und Ausstieg - sprachsynchroner Prompter, auch für PDF-Skripte - Mehrspur mit Sprecher-Ausgleich - Kabinenfenster für den Monitor beim Sprecher - Software- und Hardware-Monitoring
- **Bearbeitung:** Medienablage mit Suche und Vorhören auf Zielpegel - Take auf eine Bildlücke dehnen, ohne die Tonhöhe zu ändern - Sitzungsvorlagen - Kapitel für Podcasts
- **Klang:** Neuronale Entrauschung (DeepFilterNet 3) - Echtzeit-Sprachkette mit EQ, Kompressor, De-Esser, SmartLeveler - Referenzstimme je Sprecher - Musik- und FX-Bett mit Auto-Ducking
- **Plugins:** AU und VST3, fünf Insert-Plätze je Kanal, dazu Voice-, IT/FX- und Master-Gruppe (macOS)
- **Transkription:** Offline und wortgenau, Sprachmodell im Programm - Script-Editor mit korrigierbarem Transkript - Untertitel als SubRip (.srt) und WebVTT (.vtt)
- **Format-Profile:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 - Podcast (-16 LUFS), YouTube (-14 LUFS), Hörbuch, Doku, Sport - Studio 0 dB ohne Normalisierung
- **Auslieferung:** MXF mit acht Sound-Tracks, M&E der Quelle bleibt erhalten - Profile für ARD/ZDF HDF01a, ARIB RDD9 und CST AS-10 - Video-Mux - WAV, AIFF, FLAC, AAC, MP3, MP2 und Opus - MP3 mit Kapitelmarken und Kapiteldatei - AES31-3-Schnittliste (ADL)
- **Schnittstellen:** Virtuelle Kamera und virtuelles Audiogerät - Mackie MCU - Elgato Stream Deck - OSC - Web-Konsole für MakePro X
- **Datenschutz:** Alles läuft lokal auf dem eigenen Rechner: kein Cloud-Sync, kein Upload, kein Streaming
- **Technik:** Nativ in C++ auf JUCE 8
- **Preis:** Abo 24,99 EUR im Monat oder 249 EUR im Jahr, inkl. MwSt., monatlich kündbar - sieben Tage kostenlos testen, ohne Konto und ohne E-Mail
- **Version:** 1.6.0 (September 2026)
- **Hersteller:** pegelWERK - Sascha Hömske, Siegburg, Deutschland
- **Web:** pegelwerk.com - info@pegelwerk.com
