# voyzSESSION - Fact Sheet

**Die DAW für Sprachproduktion: Voice-over, Beitrag, Podcast, Hörspiel.**

- **Produkt:** voyzSESSION - DAW für Sprachproduktion mit AUTO MIX und Manual-Modus nach DAW-Standard
- **Kategorie:** Voice-over- und Podcast-Produktion, Audio-Postproduktion, Broadcast-Auslieferung
- **Systeme:** macOS 14 Sonoma oder neuer - empfohlen: Mac mit Apple-Prozessor (M1 oder neuer) und 16 GB Arbeitsspeicher, 32 GB für lange Projekte mit 4K-Video - Intel-Macs laufen weiterhin - iPadOS als eigene App
- **Arbeitsweisen:** Assist-Modus mit Auto Edit, Auto DSP und AUTO MIX - Manual-Modus mit Kanalzügen, Gruppen, Master-Fader und Automation in Read, Touch, Latch, Write und Trim
- **Kanalzug:** Neun Module: Restauration (De-Click, De-Plosive), Entrauschen, EQ mit dynamischen Bändern, Resonanz, De-Esser, Kompressor, De-Breath, Saturate, Hall - Werks- und eigene Presets - Signalfolge änderbar - Referenzstimme je Sprecher
- **AUTO MIX:** Analysiert jede Stimme vor dem Mischen (Klangfarbe, Dynamik, S-Schärfe, Atmer, Klicks) und stellt EQ, Kompressor und De-Esser je Sprecher und O-Ton ein, beim Sprecher zusätzlich De-Breath und De-Click - für ungepegeltes Rohmaterial - Pegelziel je Rolle (Sprecher, O-Ton, Musik, Atmo, Stadion u. a.) - Ritt der Stimme als Linie am Take, Ducks als Automation
- **Aufnahme:** Direkt in den Projektordner, 32 Bit Fließkomma - Overdub gegen Video oder Skript - V-PUNCH, der sprachgesteuerte Ein- und Ausstieg - sprachsynchroner Prompter, auch für PDF-Skripte - Mehrspur - Kabinenfenster für den Monitor beim Sprecher - Auto Input, Software- und Hardware-Monitoring
- **Bearbeitung:** Medienablage mit Suche und Vorhören auf Zielpegel - Spuren umsortieren - Navigationszeile - Take auf eine Bildlücke dehnen - Sitzungsvorlagen - Kapitel für Podcasts
- **Plugins:** AU und VST3, fünf Insert-Plätze je Kanal, dazu Voice-, IT- und Master-Gruppe
- **Transkription:** Offline und wortgenau, Sprachmodell im Programm - Script-Editor mit korrigierbarem Transkript - Untertitel als SubRip (.srt) und WebVTT (.vtt)
- **Format-Profile:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 - Podcast (-16 LUFS), YouTube (-14 LUFS), Hörbuch, Doku, Sport - Studio 0 dB ohne Normalisierung
- **Auslieferung:** MXF mit acht Sound-Tracks, Bild unverändert durchgereicht, nicht ersetzte Tonspuren der Quelle bitgleich - Profile für ARD/ZDF HDF01a, ARIB RDD9 und CST AS-10 - Video-Mux - WAV, AIFF, FLAC, AAC, MP3, MP2 und Opus - MP3 mit Kapitelmarken - AES31-3-Schnittliste (ADL)
- **Schnittstellen:** Virtuelle Kamera und virtuelles Audiogerät - Mackie MCU - Elgato Stream Deck - OSC
- **Sprachen:** Deutsch, Englisch, Französisch, Spanisch, Italienisch, Portugiesisch
- **Datenschutz:** Alles läuft lokal auf dem eigenen Rechner: kein Cloud-Sync, kein Upload, kein Streaming
- **Technik:** Nativ in C++
- **Preis:** Abo 24,99 EUR im Monat oder 249 EUR im Jahr, inkl. MwSt., monatlich kündbar - sieben Tage kostenlos testen, ohne Konto und ohne E-Mail
- **Version:** 2.0 (November 2026)
- **Hersteller:** pegelWERK - Sascha Hömske, Siegburg, Deutschland
- **Web:** pegelwerk.com - info@pegelwerk.com
