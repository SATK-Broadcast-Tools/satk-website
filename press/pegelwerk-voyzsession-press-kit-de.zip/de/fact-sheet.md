# voyzSESSION — Fact Sheet

**Die Voice-Workstation für Voice-over, Podcast und Hörbuch**

- **Produkt:** voyzSESSION (vormals overdub STUDIO) — Vertonungs-DAW mit R128-Automatik
- **Kategorie:** Voice-over- und Podcast-Produktion, Audio-Postproduktion
- **Plattformen:** macOS 12+ (Apple Silicon + Intel, Universal Binary) · iPadOS
- **Kernfunktionen:** Aufnahme & Overdub · Auto Edit / Auto DSP / Auto Mix ·
  sprachsynchroner Prompter · neuronale Entrauschung (DeepFilterNet 3) ·
  Mehrspur mit Sprecher-Ausgleich (Dugan-Stil) · Musik-/FX-Bett mit
  Auto-Ducking · Echtzeit-Sprachkette · Video-Einbettung
- **Format-Profile:** EBU R128, Podcast (-16 LUFS), YouTube, Hörbuch, Sport,
  Doku, USA/Japan/Australien
- **Preis:** macOS-Abo 24,99 EUR/Monat oder 249 EUR/Jahr · iPad App-Store-Abo
- **Version:** 1.4.1 (Juli 2026)
- **Hersteller:** pegelWERK — Sascha Hömske, Siegburg, Deutschland
- **Web:** pegelwerk.com · **Kontakt:** info@pegelwerk.com
