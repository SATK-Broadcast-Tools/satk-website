# voyzSESSION — Fact Sheet

**Die DAW für Sprachproduktion: Voice-over, Beitrag, Podcast, Hörspiel**

- **Produkt:** voyzSESSION — DAW für Sprachproduktion mit R128-Automatik und Handmodus
- **Kategorie:** Voice-over- und Podcast-Produktion, Audio-Postproduktion, Broadcast-Auslieferung
- **Plattformen:** macOS 12+ (Apple Silicon und Intel, Universal Binary) · iPadOS
- **Arbeitsweisen:** Assist-Modus mit Auto Edit, Auto DSP und Auto Mix · Manual-Modus
  mit Kanalzügen, Gruppen und Automation in Read, Touch, Latch und Write
- **Aufnahme:** Overdub gegen Video oder Skript · V-PUNCH · sprachsynchroner Prompter ·
  Mehrspur mit Sprecher-Ausgleich
- **Klang:** Neuronale Entrauschung (DeepFilterNet 3) · Echtzeit-Sprachkette ·
  Musik- und FX-Bett mit Auto-Ducking
- **Plugins:** AU und VST3, fünf Insert-Plätze je Kanal, dazu Voice-, IT/FX- und
  Master-Gruppe (macOS)
- **Transkription:** offline und wortgenau, Sprachmodell im Programm · Script-Editor ·
  Untertitel als SubRip (.srt) und WebVTT (.vtt)
- **Format-Profile:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 ·
  Podcast (-16 LUFS), YouTube (-14 LUFS), Hörbuch, Doku, Sport
- **Auslieferung:** MXF mit acht Sound-Tracks, M&E der Quelle bleibt erhalten ·
  ARD/ZDF HDF01a, ARIB RDD9, CST AS-10 · Video-Mux · WAV, AIFF, AAC, MP3, MP2
- **Schnittstellen:** Virtuelle Kamera und virtuelles Audiogerät · Mackie Control
- **Datenschutz:** alles lokal, kein Cloud-Sync, kein Upload, kein Streaming
- **Technik:** nativ in C++ auf JUCE 8
- **Preis:** Abo 24,99 EUR/Monat oder 249 EUR/Jahr, inkl. MwSt., monatlich kündbar ·
  sieben Tage kostenlos testen, ohne Konto und ohne E-Mail
- **Version:** 1.5.0 (September 2026)
- **Hersteller:** pegelWERK — Sascha Hömske, Siegburg, Deutschland
- **Web:** pegelwerk.com · **Kontakt:** info@pegelwerk.com
