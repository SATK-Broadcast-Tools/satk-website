# pegelWERK voyzSESSION — Press Kit (EN)

Contents:
- press-release.pdf / .txt — press release
- fact-sheet.pdf / .md — fact sheet
- boilerplate.txt — pegelWERK short profile
- assets/voyzsession-icon.png — app icon (1024×1024)
- assets/voyzsession-hero.png — screenshot
- assets/pegelwerk-logo.png — maker logo

All materials are cleared for editorial use.
Press contact: Sascha Hömske · info@pegelwerk.com · pegelwerk.com
