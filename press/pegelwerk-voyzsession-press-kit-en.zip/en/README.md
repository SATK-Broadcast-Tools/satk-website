# pegelWERK voyzSESSION — Press Kit (EN)

Contents:
- press-release.pdf / .txt — press release for version 1.5.0
- fact-sheet.pdf / .md — Fact Sheet
- boilerplate.txt — short company profile
- assets/voyzsession-icon.png — App-Icon (1024x1024)
- assets/voyzsession-hero.png — Screenshot
- assets/pegelwerk-logo.png — Hersteller-Logo

All materials are cleared for editorial use.
Press contact: Sascha Hömske · info@pegelwerk.com · pegelwerk.com
