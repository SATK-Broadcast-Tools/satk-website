# pegelWERK voyzSESSION — Press Kit (EN)

Contents:
- press-release.pdf / .txt — press release for version 1.6.0
- fact-sheet.pdf / .md — fact sheet
- boilerplate.txt — pegelWERK boilerplate
- assets/voyzsession-icon.png — app icon (1024x1024)
- assets/voyzsession-hero.png — screenshot
- assets/pegelwerk-logo.png — vendor logo

All materials are cleared for editorial use.
Press contact: Sascha Hömske · info@pegelwerk.com · pegelwerk.com
