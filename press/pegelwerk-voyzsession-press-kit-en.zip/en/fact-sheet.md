# voyzSESSION – Fact Sheet

**The DAW for voice production: voice-over, reporting, podcast, radio drama.**

- **Product:** voyzSESSION – DAW for voice production with R128 automation and a manual mode
- **Category:** Voice-over and podcast production, audio post-production, broadcast delivery
- **Platforms:** macOS 12+ (Apple Silicon and Intel, universal binary) · iPadOS
- **Ways of working:** Assist mode with Auto Edit, Auto DSP and Auto Mix · manual mode with channel strips, groups and automation in Read, Touch, Latch and Write
- **Recording:** Overdub against video or script · V-PUNCH, the voice-driven in and out point · speech-aligned prompter, PDF scripts included · multitrack with speaker balancing · booth window for the monitor at the speaker
- **Sound:** Neural noise removal (DeepFilterNet 3) · real-time voice chain with EQ, compressor, de-esser, SmartLeveler · music and FX bed with auto-ducking
- **Plugins:** AU and VST3, five insert slots per channel, plus voice, IT/FX and master groups (macOS)
- **Transcription:** Offline and word-accurate, speech model included · script editor · subtitles as SubRip (.srt) and WebVTT (.vtt)
- **Format profiles:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 · podcast (-16 LUFS), YouTube (-14 LUFS), audiobook, documentary, sports · Studio 0 dB without normalisation
- **Delivery:** MXF with eight sound tracks, source M&E preserved · profiles for ARD/ZDF HDF01a, ARIB RDD9 and CST AS-10 · video mux · WAV, AIFF, AAC, MP3 and MP2 (raw and inside a WAV container)
- **Interfaces:** Virtual camera and virtual audio device · Mackie MCU · Elgato Stream Deck · OSC · web console for MakePro X
- **Privacy:** Everything runs locally on your own machine: no cloud sync, no upload, no streaming
- **Technology:** Written natively in C++ on JUCE 8
- **Price:** Subscription EUR 24.99 per month or EUR 249 per year, incl. VAT, cancellable monthly · seven-day free trial, no account, no email
- **Version:** 1.5.2 (September 2026)
- **Maker:** pegelWERK – Sascha Hömske, Siegburg, Germany
- **Web:** pegelwerk.com · info@pegelwerk.com
