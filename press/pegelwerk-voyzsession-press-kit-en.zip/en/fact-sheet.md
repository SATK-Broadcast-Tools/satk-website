# voyzSESSION — Fact Sheet

**The voice workstation for voice-over, podcast and audiobook**

- **Product:** voyzSESSION (formerly overdub STUDIO) — voiceover DAW with R128 automation
- **Category:** Voice-over and podcast production, audio post-production
- **Platforms:** macOS 12+ (Apple Silicon + Intel, universal binary) · iPadOS
- **Key features:** recording & overdub · Auto Edit / Auto DSP / Auto Mix ·
  speech-aligned prompter · neural noise removal (DeepFilterNet 3) ·
  multitrack with speaker balancing (Dugan-style) · music/FX bed with
  auto-ducking · real-time voice chain · video embedding
- **Format profiles:** EBU R128, Podcast (-16 LUFS), YouTube, audiobook,
  sports, documentary, USA/Japan/Australia
- **Price:** macOS subscription EUR 24.99/month or EUR 249/year · iPad App Store subscription
- **Version:** 1.4.1 (July 2026)
- **Maker:** pegelWERK — Sascha Hömske, Siegburg, Germany
- **Web:** pegelwerk.com · **Contact:** info@pegelwerk.com
