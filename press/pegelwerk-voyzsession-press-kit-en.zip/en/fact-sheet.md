# voyzSESSION PRO - Fact Sheet

**The DAW for voice production: voice-over, reporting, podcast, radio drama.**

- **Product:** voyzSESSION PRO - DAW for voice production with AUTO MIX and a manual mode built to DAW standard
- **Category:** Voice-over and podcast production, audio post production, broadcast delivery
- **Systems:** macOS 14 Sonoma or later - recommended: Mac with Apple silicon (M1 or newer) and 16 GB of memory, 32 GB for long projects with 4K video - Intel Macs still run - iPadOS as a separate app
- **Modes:** Assist mode with auto edit, auto DSP and AUTO MIX - manual mode with channel strips, groups, master fader and automation in read, touch, latch, write and trim
- **Channel strip:** Nine modules: restoration (de-click, de-plosive), noise reduction, EQ with dynamic bands, resonance, de-esser, compressor, de-breath, saturate, reverb - factory and user presets - signal order can be changed - reference voice per narrator
- **AUTO MIX:** Analyses every voice before mixing (timbre, dynamics, sibilance, breaths, clicks) and sets EQ, compressor and de-esser per narrator and original sound, plus de-breath and de-click on the narrator - for unlevelled raw material - level target per role (narrator, original sound, music, ambience, stadium and more) - voice ride as a line on the take, ducks as automation
- **Recording:** Straight into the project folder, 32-bit float - overdub against video or script - V-PUNCH, the voice-driven punch in and out - speech-synced prompter, PDF scripts included - multitrack - booth window for the narrator's monitor - auto input, software and hardware monitoring
- **Editing:** Media pool with search and auditioning at target level - reorder tracks - navigation bar - fit a take to a picture gap - session templates - podcast chapters
- **Plugins:** AU and VST3, five insert slots per channel, plus voice, IT and master group
- **Transcription:** Offline and word-accurate, speech model built in - script editor with correctable transcript - subtitles as SubRip (.srt) and WebVTT (.vtt)
- **Loudness profiles:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 - podcast (-16 LUFS), YouTube (-14 LUFS), audiobook, documentary, sport - studio 0 dB without normalisation
- **Delivery:** MXF with eight sound tracks, picture passed through unchanged, source tracks not replaced stay bit-identical - profiles for ARD/ZDF HDF01a, ARIB RDD9 and CST AS-10 - video mux - WAV, AIFF, FLAC, AAC, MP3, MP2 and Opus - MP3 with chapter marks - AES31-3 edit list (ADL)
- **Interfaces:** Virtual camera and virtual audio device - Mackie MCU - Elgato Stream Deck - OSC
- **Languages:** German, English, French, Spanish, Italian, Portuguese
- **Privacy:** Everything runs locally on your own machine: no cloud sync, no upload, no streaming
- **Technology:** Native C++
- **Price:** Subscription EUR 29.99 per month or EUR 299 per year, VAT included, cancellable monthly - seven-day free trial, no account and no email
- **Version:** 2.0 (November 2026)
- **Vendor:** pegelWERK - Sascha Hömske, Siegburg, Germany
- **Web:** pegelwerk.com - info@pegelwerk.com
