# voyzSESSION - Fact Sheet

**The DAW for voice production: voice-over, reporting, podcast, radio drama.**

- **Product:** voyzSESSION - DAW for voice production with R128 automation and a manual mode
- **Category:** Voice-over and podcast production, audio post production, broadcast delivery
- **Platforms:** macOS 12+ (Apple Silicon and Intel, universal binary) - iPadOS
- **Modes:** Assist mode with auto edit, auto DSP and auto mix - manual mode with channel strips, groups and automation in read, touch, latch and write
- **Recording:** Straight into the project folder, 32-bit float - overdub against video or script - V-PUNCH, the voice-driven punch in and out - voice-synced prompter, PDF scripts included - multitrack with speaker matching - booth window for the monitor at the speaker - software and hardware monitoring
- **Editing:** Media pool with search and auditioning at target level - fit a take to a gap in the picture without changing pitch - session templates - podcast chapters
- **Sound:** Neural noise removal (DeepFilterNet 3) - real-time voice chain with EQ, compressor, de-esser, SmartLeveler - reference voice per speaker - music and FX bed with auto ducking
- **Plugins:** AU and VST3, five insert slots per channel, plus voice, IT/FX and master group (macOS)
- **Transcription:** Offline and word-accurate, speech model inside the app - script editor with a correctable transcript - subtitles as SubRip (.srt) and WebVTT (.vtt)
- **Format profiles:** EBU R128, ATSC A/85, ARIB TR-B32, OP-59, CST-RT-040 - podcast (-16 LUFS), YouTube (-14 LUFS), audiobook, documentary, sport - Studio 0 dB without normalisation
- **Delivery:** MXF with eight sound tracks, the source M&E is preserved - profiles for ARD/ZDF HDF01a, ARIB RDD9 and CST AS-10 - video mux - WAV, AIFF, FLAC, AAC, MP3, MP2 and Opus - MP3 with chapter marks and a chapter file - AES31-3 edit list (ADL)
- **Interfaces:** Virtual camera and virtual audio device - Mackie MCU - Elgato Stream Deck - OSC - web console for MakePro X
- **Privacy:** Everything runs locally on your own machine: no cloud sync, no upload, no streaming
- **Technology:** Native C++ on JUCE 8
- **Price:** Subscription EUR 24.99 per month or EUR 249 per year, VAT included, cancellable monthly - seven-day free trial, no account and no email
- **Version:** 1.6.0 (September 2026)
- **Vendor:** pegelWERK - Sascha Hömske, Siegburg, Germany
- **Web:** pegelwerk.com - info@pegelwerk.com
