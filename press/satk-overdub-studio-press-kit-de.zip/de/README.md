# SATK Overdub Studio — Presskit (Deutsch)

Stand: 21. Mai 2026

Dieses Verzeichnis enthält alle Materialien, die Redaktionen für die
Berichterstattung über SATK Overdub Studio brauchen. Inhalte dürfen
frei verwendet werden, Bildmaterial unter Nennung von „SATK".

## Inhalt

| Datei | Zweck |
|---|---|
| `README.md` *(diese Datei)* | Übersicht + vollständige Pressemitteilung |
| `fact-sheet.md` | Faktenblatt: Specs, Preise, Plattformen |
| `boilerplate.txt` | Standard-Kurzbeschreibung zum Einbinden in eigene Artikel |
| `assets/satk-logo.png` | SATK Logo (Quadrat, 1183×1083, transparent möglich) |
| `assets/overdub-studio-icon.png` | App-Icon Overdub Studio (1024×1024) |
| `assets/overdub-studio-hero.png` | Hero-Screenshot der App-UI (1918×1021) |
| `assets/satk-og-image.png` | Open-Graph-Bild (1200×630) |
| `assets/press-flyer-de.png` | Press-Release-Flyer (A4, deutsch) |
| `assets/sales-flyer-de.png` | Feature-Flyer für Newsletter / Print (A4, deutsch) |

---

## Pressemitteilung

### SATK veröffentlicht Overdub Studio

#### Fokussierte Vertonungs-DAW für macOS und iPad

**Siegburg, 21. Mai 2026 —** Die unabhängige Audio-Software-Schmiede
SATK aus Siegburg hat mit Overdub Studio 1.0.1 ihre erste eigenständige
DAW veröffentlicht. Die App richtet sich an Redakteurinnen,
Sportkommentatoren, Producer und alle, die Video-Beiträge sendefertig
vertonen müssen — ohne Studio, ohne Toningenieur.

Der Workflow ist bewusst kurz: Video laden, einsprechen, fertig. Pausen
werden während der Aufnahme automatisch entfernt. Die Stimme wird
automatisch auf Sendelautstärke (EBU R128 −23 LUFS) gebracht. Ein Klick
balanciert Sprache, Musik und Effekte. Der Export bettet die fertige
Vertonung direkt in das Quellvideo ein — MXF-Integrität bleibt
durchgängig erhalten, Sync und Timecode stimmen.

Auf macOS gibt es zusätzlich einen integrierten Prompter, der über
On-Device-Spracherkennung mit der Stimme mitläuft und die Leseposition
stabil hält.

Overdub Studio ergänzt das bestehende SATK-Lineup: Broadcast Meter,
mini METER (iPhone), Loudness Correct, Easy Editor und Instant Player.
Alle Tools teilen sich dieselbe EBU-R128-Engine, sodass Messwerte und
Korrekturen zwischen den Apps konsistent sind.

#### Verfügbarkeit und Preise

- macOS Standalone: 199 € einmalig, direkt über satk.tech
- iPad-App: monatliches Abo via Apple App Store
- Kostenlose Testversion verfügbar: `https://satk.tech/overdub-studio-pro`

#### Über SATK

SATK — Sascha's Audio Tool Kit — ist eine unabhängige
Audio-Software-Schmiede aus Siegburg, gegründet von Sascha Hömske.
Das Lineup umfasst sechs native Apps für macOS, iPadOS und iPhone rund
um Broadcast, Postproduktion und Voiceover.

#### Pressekontakt

Sascha Hömske, SATK
E-Mail: `info@satk.tech`
Web: `https://satk.tech`

---

## Hinweise zur Bildverwendung

- Alle Bilder sind in hoher Auflösung enthalten, lossless als PNG
- Verwendung in Online- und Print-Berichterstattung über SATK
  ohne separate Genehmigung erlaubt, sofern „SATK" als Quelle
  genannt wird
- Veränderungen, Beschnitte und Re-Kolorierungen erlaubt
- Logo bitte nicht in seinen Proportionen ändern oder neu einfärben
