# Faktenblatt — SATK Overdub Studio

Stand: 21. Mai 2026

## Produkt

| Feld | Wert |
|---|---|
| Produkt-Name | SATK Overdub Studio |
| Version | 1.0.1 |
| Kategorie | Vertonungs-DAW (Voiceover-to-Video) |
| Release-Datum | 14. Mai 2026 (1.0), 1.0.1 als Punkt-Release |
| Hersteller | SATK — Sascha's Audio Tool Kit |
| Sitz | Siegburg, Deutschland |
| Gründer / Inhaber | Sascha Hömske |

## Plattformen

| Plattform | Vertrieb | Variante |
|---|---|---|
| macOS | Direkt über satk.tech (Paddle) | Standalone-Anwendung |
| iPad | Apple App Store | iOS-App, optimiertes Layout |

> Hinweis: Ein Windows-Build existiert intern, wird derzeit aber nicht
> aktiv für die Pressearbeit beworben.

## Systemanforderungen (macOS)

- **Empfohlen:** Apple Silicon (M-Serie) · 16 GB RAM · macOS 13 oder neuer
- **Unterstützt:** Intel Quad-Core i7 · 16 GB RAM · macOS 12

## Preise

| Plattform | Preis | Modell |
|---|---|---|
| macOS Standalone | 199 € | Einmalkauf |
| iPad (App Store) | monatliches Abo | Subscription |

> Hinweis zur Pricing-Strategie: Overdub Studio ist die **einzige**
> SATK-App mit Abo-Modell, und das nur auf iPad. Hintergrund ist das
> Apple-App-Store-Preisgefüge, in dem eine iPad-Standalone-Variante
> deutlich unter dem macOS-Standalone-Preis liegen müsste und die
> Desktop-Version kannibalisieren würde. Auf allen anderen SATK-Apps
> bleibt es bei Einmalkauf.

## Kernfunktionen

- **Auto Edit** — Pausen werden während der Aufnahme automatisch
  entfernt; Versprecher einfach neu drüber sprechen
- **Auto Audio** — Automatische Stimmbearbeitung auf Sendelautstärke
  (EBU R128 −23 LUFS)
- **Auto Mix** — One-Click-Balance für Sprache, Musik und Effekte
- **Integrierter Prompter** — Text läuft mit der Stimme mit
  (macOS desktop, On-Device-Spracherkennung)
- **Video-In / Video-Out** — Finale Vertonung wird direkt in das
  Quellvideo eingebettet, MXF-Integrität durchgängig erhalten
- **Recording-Komfort** — Pre-Roll, Pegelanzeige, direktes Monitoring

## SATK Tool-Familie

Overdub Studio teilt sich die EBU-R128-DSP-Engine mit fünf weiteren
SATK-Apps:

- **Broadcast Meter** — Loudness-Meter (macOS, iPad)
- **mini METER** — Loudness-Meter für iPhone
- **Loudness Correct** — Offline-Lautheitskorrektur (macOS, iPad)
- **Easy Editor** — Audio-Cutter mit R128-Export (iPhone, iPad)
- **Instant Player** — 64-Pad-Soundboard (iPhone, iPad)

## Distribution & Lizenzierung

- **macOS:** Hardware-gebundene Lizenz via SATK License Worker
  (Ed25519-Token), 2 Geräte pro Lizenz, kein iLok, kein USB-Dongle
- **iPad:** Standard Apple App Store DRM (FairPlay)
- **Kostenlose Testversion** verfügbar

## URLs

| Zweck | URL |
|---|---|
| Produkt-Seite | `https://satk.tech/overdub-studio-pro` |
| Download macOS DMG | `https://satk.tech/download/satk-overdub-studio-1.0.1.dmg` |
| Hersteller-Website | `https://satk.tech` |
| Pressekontakt | `info@satk.tech` |
