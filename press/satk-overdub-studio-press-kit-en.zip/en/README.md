# SATK Overdub Studio — Press Kit (English)

As of: 21 May 2026

This directory contains all materials editorial teams need to cover
SATK Overdub Studio. Texts may be reused freely; image assets are
licensed for editorial use with credit to "SATK".

## Contents

| File | Purpose |
|---|---|
| `README.md` *(this file)* | Overview + full press release |
| `fact-sheet.md` | Specs, pricing, platforms |
| `boilerplate.txt` | Short standard description for embedding in articles |
| `assets/satk-logo.png` | SATK logo (square, 1183×1083) |
| `assets/overdub-studio-icon.png` | Overdub Studio app icon (1024×1024) |
| `assets/overdub-studio-hero.png` | Hero screenshot of the app UI (1918×1021) |
| `assets/satk-og-image.png` | Open Graph image (1200×630) |
| `assets/press-flyer-en.png` | Press release flyer (A4, English) |
| `assets/sales-flyer-en.png` | Feature flyer for newsletters / print (A4, English) |

---

## Press Release

### SATK releases Overdub Studio

#### Focused voiceover DAW for macOS and iPad

**Siegburg, Germany, 21 May 2026 —** Independent audio-software studio
SATK from Siegburg has released Overdub Studio 1.0.1, its first
standalone DAW. The app targets editors, sports commentators, producers
and anyone delivering voiced video content under broadcast time
pressure — without a studio setup, and without a sound engineer in the
loop.

The workflow is intentionally short: load video, voice it, deliver.
Pauses are removed automatically during recording. The voice is
processed to broadcast loudness (EBU R128 −23 LUFS) automatically. One
click balances voice, music and effects. The export embeds the
finished mix straight into the source video file, preserving MXF
integrity end-to-end.

On macOS, Overdub Studio also includes a built-in prompter that scrolls
with the speaker's voice via on-device speech recognition.

Overdub Studio joins SATK's existing line — Broadcast Meter, mini METER
(iPhone), Loudness Correct, Easy Editor and Instant Player. All apps
share the same EBU R128 DSP engine, so measurements and corrections
are consistent across the suite.

#### Availability and Pricing

- macOS Standalone: 199 € one-time, direct from satk.tech
- iPad app: monthly subscription via the Apple App Store
- Free trial available: `https://satk.tech/overdub-studio-pro`

#### About SATK

SATK — Sascha's Audio Tool Kit — is an independent audio-software
studio based in Siegburg, Germany, founded by Sascha Hömske. The line
covers six native apps for macOS, iPadOS and iPhone, focused on
broadcast, post-production and voiceover.

#### Press Contact

Sascha Hömske, SATK
Email: `info@satk.tech`
Web: `https://satk.tech`

---

## Image usage notes

- All images are provided at high resolution as PNGs
- Free use in online and print coverage about SATK, no separate
  permission required, provided "SATK" is credited as the source
- Crops, recolouring and editorial adjustments are allowed
- Please do not stretch the logo or recolour it
