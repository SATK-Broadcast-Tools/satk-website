# Fact Sheet — SATK Overdub Studio

As of: 21 May 2026

## Product

| Field | Value |
|---|---|
| Product name | SATK Overdub Studio |
| Version | 1.0.1 |
| Category | Voiceover-to-video DAW |
| Release date | 14 May 2026 (1.0), 1.0.1 follow-up point release |
| Vendor | SATK — Sascha's Audio Tool Kit |
| Headquarters | Siegburg, Germany |
| Founder / Owner | Sascha Hömske |

## Platforms

| Platform | Distribution | Variant |
|---|---|---|
| macOS | Direct from satk.tech (Paddle) | Standalone application |
| iPad | Apple App Store | iOS app, optimised layout |

> Note: A Windows build exists internally but is not actively
> promoted in press materials at this time.

## System Requirements (macOS)

- **Recommended:** Apple Silicon (M-series) · 16 GB RAM · macOS 13 or later
- **Supported:** Intel Quad-Core i7 · 16 GB RAM · macOS 12

## Pricing

| Platform | Price | Model |
|---|---|---|
| macOS Standalone | 199 € | One-time purchase |
| iPad (App Store) | monthly subscription | Subscription |

> Note on pricing strategy: Overdub Studio is the **only** SATK app
> with a subscription model, and only on iPad. The reason is the
> Apple App Store pricing structure, where an iPad standalone variant
> would have to be priced significantly lower than the macOS
> standalone and would cannibalise it. All other SATK apps remain
> one-time purchases.

## Core Features

- **Auto Edit** — pauses are removed automatically while recording;
  for fluffs, just speak the line again
- **Auto Audio** — automatic voice processing to broadcast loudness
  (EBU R128 −23 LUFS)
- **Auto Mix** — one-click balance for voice, music and effects
- **Built-in prompter** — script scrolls with the speaker's voice
  (macOS desktop, on-device speech recognition)
- **Video in / video out** — finished mix is embedded straight into
  the source video, with MXF integrity preserved end-to-end
- **Recording essentials** — pre-roll, level metering, direct monitoring

## SATK Tool Family

Overdub Studio shares its EBU R128 DSP engine with five other SATK
apps:

- **Broadcast Meter** — loudness meter (macOS, iPad)
- **mini METER** — loudness meter for iPhone
- **Loudness Correct** — offline loudness correction (macOS, iPad)
- **Easy Editor** — audio cutter with R128 export (iPhone, iPad)
- **Instant Player** — 64-pad soundboard (iPhone, iPad)

## Distribution & Licensing

- **macOS:** Hardware-bound license via SATK License Worker
  (Ed25519-signed token), 2 devices per license, no iLok, no USB dongle
- **iPad:** Standard Apple App Store DRM (FairPlay)
- **Free trial** available

## URLs

| Purpose | URL |
|---|---|
| Product page | `https://satk.tech/overdub-studio-pro` |
| macOS DMG download | `https://satk.tech/download/satk-overdub-studio-1.0.1.dmg` |
| Vendor website | `https://satk.tech` |
| Press contact | `info@satk.tech` |
